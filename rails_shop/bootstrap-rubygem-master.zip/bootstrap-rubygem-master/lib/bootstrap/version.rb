module Bootstrap
  VERSION       = '4.0.0.beta3'
  BOOTSTRAP_SHA = 'ced70da441d487efb8589acbff445d6b5fa68bb9'
end
